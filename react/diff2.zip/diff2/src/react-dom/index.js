import render from './render'

export default {
  render
}